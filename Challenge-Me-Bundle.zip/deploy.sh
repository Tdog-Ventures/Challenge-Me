#!/bin/bash
set -e
echo "=== Challenge-Me Autonomous Deploy ==="
echo "PWD: $(pwd)"
echo "Files:"
ls -la
echo ""
echo "Checking secrets..."
if [ -z "$VERCEL_TOKEN" ]; then
  echo "VERCEL_TOKEN missing - trying Vercel CLI login check"
  if [ -f ~/.vercel/auth.json ]; then
    echo "Found ~/.vercel/auth.json"
  else
    echo "No token, will need manual vercel login or env"
  fi
else
  echo "VERCEL_TOKEN present: ${#VERCEL_TOKEN} chars"
fi

echo ""
echo "Installing deps..."
npm install

echo ""
echo "Building..."
npm run build

echo ""
echo "Build complete. Ready for vercel deploy --prod"
if [ -n "$VERCEL_TOKEN" ]; then
  npx vercel --prod --yes --token=$VERCEL_TOKEN --scope=tdog-ventures || npx vercel deploy --prod --yes --token=$VERCEL_TOKEN
else
  echo "Run: npx vercel --prod --yes"
fi
