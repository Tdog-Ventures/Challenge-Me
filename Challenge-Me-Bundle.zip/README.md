# Challenge-Me
Stop the moving image in the target zone.

Live URL format:
https://challenge-me.vercel.app/?image=URL&message=TEXT&zone=80&speed=6&outline=%2300FF88

Auto-posts to Facebook via /api/cron/facebook - 9am, 1pm, 6pm Adelaide
Env required: FB_PAGE_ID, FB_PAGE_TOKEN, NEXT_PUBLIC_BASE_URL
